﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfFirst
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Button but;
        Timer timer1;
        public MainWindow()
        {
            InitializeComponent();
            string[] lang = { "C++", "C#", "Java", "PHP" };
            foreach (string s in lang)
            {
                TreeView1.Items.Add(s);
                Tree2.Items.Add(s);
                List2.Items.Add(s);
            }
            but = new Button() { Content = "ProgButton", Margin=new Thickness(3) };
            StackPan1.Children.Insert(1, but);
            timer1 = new Timer { Interval = 1000, Enabled = true };
            timer1.Elapsed += (o, e) =>
            {
                Dispatcher.Invoke(
                    ()=>Progress1.Value = Convert.ToDouble(DateTime.Now.Second)
                );
            };
        }

        private void TreeView1_SelectedItemChanged(object sender, RoutedPropertyChangedEventArgs<object> e)
        {
            ListView1.Items.Clear();
            ListView1.Items.Add(e.NewValue);
            ListView1.Items.Add(TreeView1.SelectedItem);

        }
    }
}
